export const footerLinks = [
    {
      title: "Useful Links",
      links: [
        { name: "Content" },
        { name: "How it Works" },
        { name: "Create" },
        { name: "Explore" },
        { name: "Terms & Services" },
      ],
    },
  ];
  
  export const socialMedia = [
    {
      id: "social-media-1",
      icon: "/path-to-icon",
      link: "https://www.facebook.com/",
    },
  ];