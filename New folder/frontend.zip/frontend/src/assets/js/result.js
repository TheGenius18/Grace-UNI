export default [
    {
        "text": "While your symptoms are likely not having a major impact on your life, it may still be helpful to monitor them. It is recommended that you retake this test once every two weeks.",
        "type": 1
    },
    {
        "text": "While your symptoms are likely not having a major impact on your life, it may still be helpful to monitor them. It is recommended that you retake this test once every two weeks.",
        "type": 2
    },
    {
        "text": "While this is not a diagnostic test, it may be worthwhile to start a conversation with your doctor or mental health professional. Finding the right treatment plan can help you on the path toward feeling better. It is also recommended that you monitor your symptoms by retaking this test once every two weeks.",
        "type": 3
    },
    {
        "text": "While this is not a diagnostic test, people who scored similar to you typically receive a diagnosis of major depression and have sought professional treatment for this disorder. It may be beneficial for you to consult your doctor or mental health professional immediately.",
        "type": 4
    },
    {
        "text": "While this is not a diagnostic test, people who scored similar to you typically receive a diagnosis of major depression and have sought professional treatment for this disorder. It may be beneficial for you to consult your doctor or mental health professional immediately.",
        "type": 5
    }
];