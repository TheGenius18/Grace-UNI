/* eslint-disable no-unused-vars */
// App.js
import React from "react";
import { createRoot } from "react-dom";
import App from "./src/App"; // Your main React component
// import "./src/assets/js/homepage-nav"; // Import your external JS file

createRoot(document.getElementById("root")).render(<App />);
