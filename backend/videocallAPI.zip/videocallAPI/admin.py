from django.contrib import admin

from .models import Room
from API.models import CustomUser  


admin.site.register(Room)


# Register your models here
